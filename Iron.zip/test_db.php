<?php

require_once __DIR__ . '/config/db.php';

echo "<h1>PCare Database Connection Test</h1>";

try {

    $database = $pdo->query("SELECT DATABASE()")->fetchColumn();

    $units = $pdo->query(
        "SELECT COUNT(*) FROM computer_units"
    )->fetchColumn();

    $categories = $pdo->query(
        "SELECT COUNT(*) FROM issue_categories"
    )->fetchColumn();

    echo "<p>Database: " .
         htmlspecialchars($database) . "</p>";

    echo "<p>Computer Units: " . $units . "</p>";

    echo "<p>Issue Categories: " . $categories . "</p>";

    echo "<h2 style='color:green;'>Connection Successful!</h2>";

} catch (PDOException $e) {

    error_log($e->getMessage());

    echo "<h2 style='color:red;'>Database Test Failed!</h2>";

}