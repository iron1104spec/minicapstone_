<?php
// it-personnel/maintenance-records.php
require_once __DIR__ . '/maintenance-records-logic.php';

// Kunin ang pangalan ng user (fallback kung wala sa logic file)
$fullName = $_SESSION['full_name'] ?? 'IT Personnel';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Maintenance Records | PCare</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

    <!-- External CSS -->
    <link rel="stylesheet" href="../assets/css/personnel-maintenance-records.css">

    <!-- BAGONG LAYOUT CSS (Floating Dock) -->
    <style>
        body {
            background-color: #f4f7f6;
            font-family: 'Inter', sans-serif;
        }

        /* --- TOP HEADER --- */
        .custom-topbar {
            position: fixed; top: 0; left: 0; width: 100%; height: 70px;
            background: #ffffff; display: flex; justify-content: space-between;
            align-items: center; padding: 0 30px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); z-index: 9999;
        }
        .brand-area { display: flex; align-items: center; gap: 10px; text-decoration: none; color: inherit; }
        .brand-icon { font-size: 24px; color: #0d2f24; }
        .brand-name { display: block; font-weight: 800; font-size: 18px; color: #0d2f24; line-height: 1; }
        .brand-caption { display: block; font-size: 9px; letter-spacing: 1px; color: #666; font-weight: 600; }

        /* --- FLOATING DOCK --- */
        .floating-dock {
            position: fixed; bottom: 25px; left: 50%; transform: translateX(-50%);
            display: flex; flex-direction: row; gap: 8px; background-color: #0d2f24;
            padding: 12px 24px; border-radius: 50px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3), 0 1px 3px rgba(0, 0, 0, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.1); z-index: 9999;
            max-width: 95%; overflow-x: auto;
        }
        .floating-dock::-webkit-scrollbar { display: none; }
        .dock-item {
            display: flex; flex-direction: column; align-items: center; justify-content: center;
            color: #a0b8b0; text-decoration: none; padding: 10px 20px;
            border-radius: 16px; transition: all 0.3s ease; white-space: nowrap;
        }
        .dock-item i { font-size: 20px; margin-bottom: 4px; }
        .dock-item span { font-size: 11px; font-weight: 500; }
        .dock-item:hover { background-color: rgba(255, 255, 255, 0.1); color: #ffffff; transform: translateY(-4px); }
        .dock-item.active { background-color: #1a4a3a; color: #ffffff; }

        /* --- MAIN CONTENT SPACING --- */
        .main-wrapper {
            padding-top: 100px; 
            padding-bottom: 120px; 
            width: 100%;
        }
    </style>
</head>

<body>

<!-- BAGONG TOP HEADER (Logo & Profile) -->
<header class="custom-topbar">
    <a href="dashboard.php" class="brand-area">
        <span class="brand-icon"><i class="bi bi-pc-display-horizontal"></i></span>
        <span>
            <span class="brand-name">PCare</span>
            <span class="brand-caption">IT PERSONNEL PORTAL</span>
        </span>
    </a>
    <div class="d-flex align-items-center gap-3">
        <span class="topbar-date d-none d-md-inline text-muted" style="font-size: 14px;">
            <i class="bi bi-calendar3 me-1"></i> <?= date('F d, Y') ?>
        </span>
        <div class="d-flex align-items-center gap-2 border-start ps-3">
            <div class="topbar-avatar bg-dark text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px; font-weight: bold; font-size: 14px;">
                IT
            </div>
            <div class="d-none d-sm-block">
                <div class="profile-name" style="font-size: 14px; font-weight: 600; margin: 0; line-height: 1.2;"><?= e($fullName) ?></div>
                <div class="profile-role" style="font-size: 12px; color: #666; margin: 0;">IT Personnel</div>
            </div>
            <a href="../logout.php" class="btn btn-sm btn-outline-danger ms-2" title="Logout">
                <i class="bi bi-box-arrow-right"></i>
            </a>
        </div>
    </div>
</header>

<!-- MAIN CONTENT -->
<div class="main-wrapper">
    <main class="container-fluid px-lg-4 py-4">

        <!-- Page Heading -->
        <div class="mb-4">
            <p class="text-muted small mb-1">IT Personnel / Maintenance</p>
            <h2 class="page-heading mb-2 fw-bold" style="color: #0f172a;">Maintenance Records</h2>
            <p class="text-muted mb-0">
                Document inspections, troubleshooting actions, and repair results for reported computer issues.
            </p>
        </div>

        <!-- Success Notification -->
        <?php if ($success): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <i class="bi bi-check-circle me-2"></i>
                <?= e($success) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Error Notification -->
        <?php if ($error): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <i class="bi bi-exclamation-circle me-2"></i>
                <?= e($error) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Create Maintenance Record -->
        <section class="content-card p-4 mb-4 bg-white shadow-sm" style="border-radius: 12px;">
            <div class="mb-4">
                <h5 class="section-title mb-1 fw-bold" style="color: #334155;">
                    <i class="bi bi-clipboard-plus me-2 text-success"></i> Create Maintenance Record
                </h5>
                <p class="text-muted small mb-0">Select an issue report and document the maintenance activity.</p>
            </div>

            <form method="POST" action="">
                <?= csrf_field() ?>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="report_id" class="form-label fw-semibold" style="font-size: 13px;">Issue Report <span class="text-danger">*</span></label>
                        <select name="report_id" id="report_id" class="form-select" required>
                            <option value="">Select an issue report</option>
                            <?php foreach ($availableReports as $report): ?>
                                <option value="<?= (int) $report['report_id'] ?>">
                                    <?= e($report['reference_no']) ?> — <?= e($report['unit_code']) ?> (<?= e($report['status']) ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-3">
                        <label for="inspection_date" class="form-label fw-semibold" style="font-size: 13px;">Inspection Date</label>
                        <input type="datetime-local" name="inspection_date" id="inspection_date" class="form-control">
                    </div>

                    <div class="col-md-3">
                        <label for="maintenance_date" class="form-label fw-semibold" style="font-size: 13px;">Maintenance Date</label>
                        <input type="datetime-local" name="maintenance_date" id="maintenance_date" class="form-control">
                    </div>

                    <div class="col-md-12">
                        <label for="findings" class="form-label fw-semibold" style="font-size: 13px;">Inspection Findings <span class="text-danger">*</span></label>
                        <textarea name="findings" id="findings" class="form-control" rows="3" placeholder="Describe the problem found during inspection..." required></textarea>
                    </div>

                    <div class="col-md-12">
                        <label for="action_taken" class="form-label fw-semibold" style="font-size: 13px;">Actions Taken <span class="text-danger">*</span></label>
                        <textarea name="action_taken" id="action_taken" class="form-control" rows="3" placeholder="Describe the troubleshooting or repair actions performed..." required></textarea>
                    </div>

                    <div class="col-md-12">
                        <label for="repair_result" class="form-label fw-semibold" style="font-size: 13px;">Repair Result <span class="text-danger">*</span></label>
                        <textarea name="repair_result" id="repair_result" class="form-control" rows="3" placeholder="Describe the result after maintenance..." required></textarea>
                    </div>

                    <div class="col-12 d-flex justify-content-end">
                        <button type="submit" class="btn btn-pcare fw-semibold" style="border-radius: 8px;">
                            <i class="bi bi-save me-2"></i> Save Maintenance Record
                        </button>
                    </div>
                </div>
            </form>
        </section>

        <!-- Maintenance Records Table -->
        <section class="content-card p-4 bg-white shadow-sm" style="border-radius: 12px;">
            <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
                <div>
                    <h5 class="section-title mb-1 fw-bold" style="color: #334155;">Saved Maintenance Records</h5>
                    <p class="text-muted small mb-0">Maintenance activities recorded in the database.</p>
                </div>
                <span class="badge rounded-pill text-bg-light border" style="font-size: 12px; padding: 6px 12px;"><?= count($maintenanceRecords) ?> Records</span>
            </div>

            <?php if (count($maintenanceRecords) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th style="font-size: 11px; text-transform: uppercase; color: #64748b;">Reference No.</th>
                                <th style="font-size: 11px; text-transform: uppercase; color: #64748b;">Computer Unit</th>
                                <th style="font-size: 11px; text-transform: uppercase; color: #64748b;">Inspection Date</th>
                                <th style="font-size: 11px; text-transform: uppercase; color: #64748b;">Maintenance Date</th>
                                <th style="font-size: 11px; text-transform: uppercase; color: #64748b;">Personnel</th>
                                <th style="font-size: 11px; text-transform: uppercase; color: #64748b;">Issue Status</th>
                                <th style="font-size: 11px; text-transform: uppercase; color: #64748b;">Repair Result</th>
                                <th style="font-size: 11px; text-transform: uppercase; color: #64748b;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($maintenanceRecords as $record): ?>
                                <tr>
                                    <td class="fw-semibold text-success" style="font-size: 13px;"><?= e($record['reference_no']) ?></td>
                                    <td style="font-size: 13px;"><?= e($record['unit_code']) ?></td>
                                    <td style="font-size: 13px;">
                                        <?= $record['inspection_date'] ? e(date('M d, Y h:i A', strtotime($record['inspection_date']))) : '<span class="text-muted">Not set</span>' ?>
                                    </td>
                                    <td style="font-size: 13px;">
                                        <?= $record['maintenance_date'] ? e(date('M d, Y h:i A', strtotime($record['maintenance_date']))) : '<span class="text-muted">Not set</span>' ?>
                                    </td>
                                    <td style="font-size: 13px;"><?= e($record['personnel_name']) ?></td>
                                    <td>
                                        <span class="status-badge"><?= e($record['status']) ?></span>
                                    </td>
                                    <td style="font-size: 13px;"><?= e($record['repair_result']) ?></td>
                                    <td>
                                        <a href="maintenance-details.php?id=<?= (int) $record['maintenance_id'] ?>" class="btn-view text-decoration-none">
                                            <i class="bi bi-eye me-1"></i> View Details
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="empty-state text-center py-5">
                    <i class="bi bi-clipboard2-x d-block mb-3 text-muted" style="font-size: 40px;"></i>
                    <h6 class="fw-semibold text-dark">No maintenance records yet</h6>
                    <p class="small mb-0 text-muted">
                        Once an IT Personnel member saves a maintenance record, it will appear here.
                    </p>
                </div>
            <?php endif; ?>
        </section>

    </main>
</div>

<!-- FLOATING BOTTOM DOCK (Menu para sa IT Personnel) -->
<nav class="floating-dock">
    <a href="dashboard.php" class="dock-item">
        <i class="bi bi-grid-1x2-fill"></i><span>Dashboard</span>
    </a>
    <a href="issue-reports.php" class="dock-item">
        <i class="bi bi-clipboard-data"></i><span>Issue Reports</span>
    </a>
    <a href="maintenance-records.php" class="dock-item active">
        <i class="bi bi-tools"></i><span>Maintenance</span>
    </a>
</nav>

<!-- Bootstrap JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>