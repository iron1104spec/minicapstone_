
<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/csrf.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Test Logout | PCare</title>
</head>
<body>

    <h2>PCare Logout Test</h2>

    <form action="logout.php" method="POST">
        <?= csrf_field() ?>
        <button type="submit">Test Logout</button>
    </form>

</body>
</html>
