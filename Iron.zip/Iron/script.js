const feedbackForm = document.getElementById('feedbackForm');

feedbackForm.addEventListener('submit', function(event) {
    event.preventDefault();

    const name = document.getElementById('name').value.trim();
    const ageValue = document.getElementById('age').value;
    const emailInput = document.getElementById('email');
    const email = emailInput.value.trim();
    const categoryInput = document.getElementById('favorite-drink');
    const ratingInput = document.getElementById('rating');
    const comments = document.getElementById('comments').value.trim();

    const errorMsg = document.getElementById('errorMsg');
    const outputContainer = document.getElementById('outputContainer');
    const greetingOutput = document.getElementById('greetingOutput');

    const age = Number(ageValue);

    if (
        name === '' ||
        ageValue === '' ||
        email === '' ||
        categoryInput.value === '' ||
        ratingInput.value === '' ||
        comments === ''
    ) {
        errorMsg.textContent = 'Please fill in all feedback fields.';
        errorMsg.style.display = 'block';
        outputContainer.style.display = 'none';
        outputContainer.classList.add('hidden');
        greetingOutput.textContent = '';
        return;
    }

    if (emailInput.validity.typeMismatch) {
        errorMsg.textContent = 'Please enter a valid email address.';
        errorMsg.style.display = 'block';
        outputContainer.style.display = 'none';
        outputContainer.classList.add('hidden');
        greetingOutput.textContent = '';
        return;
    }

    if (age < 0 || !Number.isInteger(age)) {
        errorMsg.textContent = 'Please enter a valid age using a whole number.';
        errorMsg.style.display = 'block';
        outputContainer.style.display = 'none';
        outputContainer.classList.add('hidden');
        greetingOutput.textContent = '';
        return;
    }

    errorMsg.style.display = 'none';

    const greeting = generateGreeting(name, age);
    greetingOutput.textContent = greeting;

    document.getElementById('outputname').textContent = name;
    document.getElementById('outputage').textContent = age;
    document.getElementById('outputemail').textContent = email;

    document.getElementById('outputcategory').textContent =
        categoryInput.options[categoryInput.selectedIndex].text;

    document.getElementById('outputrating').textContent =
        ratingInput.options[ratingInput.selectedIndex].text;

    document.getElementById('outputmessage').textContent = comments;

    outputContainer.classList.remove('hidden');
    outputContainer.style.display = 'block';
});

function generateGreeting(name, age) {
    let status;

    if (age < 18) {
        status = 'You are a minor.';
    } else {
        status = 'You are an adult.';
    }

    return 'Hello, ' + name + '! You are ' + age +
        ' years old. ' + status;
}


/* Activity 2: Interactive Registration Form */

const registrationForm = document.getElementById('registrationForm');

registrationForm.addEventListener('submit', function(event) {
    event.preventDefault();

    const fullName = document.getElementById('fullName').value.trim();
    const emailInput = document.getElementById('registerEmail');
    const email = emailInput.value.trim();
    const password = document.getElementById('password').value;

    const message = document.getElementById('registrationMessage');

    if (
        fullName === '' ||
        email === '' ||
        password.trim() === ''
    ) {
        message.textContent = 'Error: Please complete all fields.';
        message.className = 'error';
        return;
    }

    if (emailInput.validity.typeMismatch) {
        message.textContent = 'Error: Please enter a valid email address.';
        message.className = 'error';
        return;
    }

    message.textContent =
        'Registration successful! Welcome to Kopiron, ' + fullName + '!';

    message.className = 'success';

    registrationForm.reset();
});
