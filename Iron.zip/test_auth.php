
<?php
require_once __DIR__ . '/includes/auth.php';

// Only logged-in student accounts can access this page.
require_role('student');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Access Test | PCare</title>
</head>
<body>

    <h1>PCare Access Test</h1>

    <h2>Access Granted!</h2>

    <p>
        Welcome, <?= e($_SESSION['full_name']) ?>!
    </p>

    <p>
        Your role: <?= e($_SESSION['role']) ?>
    </p>

    <p>Your account successfully passed the access protection test.</p>

</body>
</html>
